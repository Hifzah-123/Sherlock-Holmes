import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import OpenAI from "openai";
import { v4 as uuidv4 } from "uuid";

// API routes for chat history
async function getChatHistoryRoutes(req: Request, res: Response) {
  try {
    // For now, we're using a guest user (null userId)
    // In a real app, you'd get the userId from the session
    const userId = null;
    
    const chats = await storage.getUserChats(userId);
    
    // Format the chats for the frontend
    const formattedChats = chats.map(chat => ({
      id: chat.id,
      title: chat.title,
      date: chat.createdAt.toLocaleString()
    }));
    
    res.json({ chats: formattedChats });
  } catch (error) {
    console.error("Error fetching chat history:", error);
    res.status(500).json({ error: "Failed to fetch chat history" });
  }
}

// API Routes for detective rank system
async function getUserRankRoute(req: Request, res: Response) {
  try {
    const { guestId } = req.params;
    
    if (!guestId) {
      return res.status(400).json({ error: "Guest ID is required" });
    }
    
    // Get or create a user rank for this guest
    let userRank = await storage.getUserRank(null, guestId);
    
    // If no rank exists yet, create it
    if (!userRank) {
      userRank = await storage.createUserRank({
        userId: null,
        guestId,
        rankLevel: "newbie_detective"
      });
    }
    
    // Get achievements for this user
    const achievements = await storage.getUserAchievements(userRank.id);
    
    // Determine rank based on points
    let rankTitle = "Newbie Detective";
    let rankDescription = "Just starting your journey into the world of deduction.";
    let nextRankTitle = "Inspector";
    let nextRankPoints = 30;
    let progressPercent = Math.min(100, (userRank.rankPoints / nextRankPoints) * 100);
    
    if (userRank.rankPoints >= 75) {
      rankTitle = "Chief Investigator";
      rankDescription = "A master of logic and deduction, rivaling Holmes himself.";
      nextRankTitle = "";
      nextRankPoints = 0;
      progressPercent = 100;
    } else if (userRank.rankPoints >= 30) {
      rankTitle = "Inspector";
      rankDescription = "Skilled at following evidence and uncovering hidden truths.";
      nextRankTitle = "Chief Investigator";
      nextRankPoints = 75;
      progressPercent = Math.min(100, ((userRank.rankPoints - 30) / (75 - 30)) * 100);
    }
    
    // Prepare response object
    const response = {
      userRank: {
        ...userRank,
        rankTitle,
        rankDescription,
        nextRankTitle,
        nextRankPoints,
        progressPercent
      },
      achievements: achievements.map(a => ({
        id: a.id,
        name: a.achievement.name,
        description: a.achievement.description,
        badgeIcon: a.achievement.badgeIcon,
        pointsAwarded: a.achievement.pointsAwarded,
        awardedAt: a.awardedAt
      })),
      stats: {
        questionsAsked: userRank.questionsAsked,
        logicalQuestionsAsked: userRank.logicalQuestionsAsked,
        mysteriesSolved: userRank.mysteriesSolved,
        cluesAnalyzed: userRank.cluesAnalyzed,
        pointsToNextRank: nextRankPoints > 0 ? nextRankPoints - userRank.rankPoints : 0
      }
    };
    
    res.json(response);
  } catch (error) {
    console.error("Error fetching user rank:", error);
    res.status(500).json({ error: "Failed to fetch user rank" });
  }
}

async function updateUserRankRoute(req: Request, res: Response) {
  try {
    const { guestId } = req.params;
    const { action } = req.body;
    
    if (!guestId) {
      return res.status(400).json({ error: "Guest ID is required" });
    }
    
    // Get user rank
    let userRank = await storage.getUserRank(null, guestId);
    
    if (!userRank) {
      userRank = await storage.createUserRank({
        userId: null,
        guestId,
        rankLevel: "newbie_detective"
      });
    }
    
    // Update based on action
    const updates: any = {};
    let achievementId = null;
    
    switch (action) {
      case 'askQuestion':
        updates.questionsAsked = userRank.questionsAsked + 1;
        updates.rankPoints = userRank.rankPoints + 1;
        
        // Check for first question achievement
        if (updates.questionsAsked === 1) {
          // This would be the ID of "First Consultation" achievement
          achievementId = 1;
        }
        break;
        
      case 'askLogicalQuestion':
        updates.questionsAsked = userRank.questionsAsked + 1;
        updates.logicalQuestionsAsked = userRank.logicalQuestionsAsked + 1;
        updates.rankPoints = userRank.rankPoints + 2;
        
        // Check for logical thinker achievement
        if (updates.logicalQuestionsAsked === 10) {
          // This would be the ID of "Logical Thinker" achievement
          achievementId = 4;
        }
        break;
        
      case 'solveMystery':
        updates.mysteriesSolved = userRank.mysteriesSolved + 1;
        updates.rankPoints = userRank.rankPoints + 5;
        
        // Check for mystery solver achievement
        if (updates.mysteriesSolved === 1) {
          // This would be the ID of "Mystery Solver" achievement
          achievementId = 2;
        }
        break;
        
      case 'analyzeClue':
        updates.cluesAnalyzed = userRank.cluesAnalyzed + 1;
        updates.rankPoints = userRank.rankPoints + 2;
        
        // Check for clue master achievement
        if (updates.cluesAnalyzed === 5) {
          // This would be the ID of "Clue Master" achievement
          achievementId = 3;
        }
        break;
        
      default:
        return res.status(400).json({ error: "Invalid action" });
    }
    
    // Update user rank
    const updatedRank = await storage.updateUserRank(userRank.id, updates);
    
    // Award achievement if applicable
    if (achievementId) {
      await storage.awardAchievement(userRank.id, achievementId);
    }
    
    // Check for rank promotion
    if (
      (userRank.rankLevel === "newbie_detective" && updatedRank.rankPoints >= 30) ||
      (userRank.rankLevel === "inspector" && updatedRank.rankPoints >= 75)
    ) {
      // Promote user
      const newRankLevel = userRank.rankLevel === "newbie_detective" ? "inspector" : "chief_investigator";
      await storage.updateUserRank(userRank.id, { rankLevel: newRankLevel });
      
      // If reached the highest rank, award elite detective achievement
      if (newRankLevel === "chief_investigator") {
        // This would be the ID of "Elite Detective" achievement
        await storage.awardAchievement(userRank.id, 5);
      }
    }
    
    // Return updated rank info
    return getUserRankRoute(req, res);
    
  } catch (error) {
    console.error("Error updating user rank:", error);
    res.status(500).json({ error: "Failed to update user rank" });
  }
}

async function getChatMessagesRoute(req: Request, res: Response) {
  try {
    const { chatId } = req.params;
    
    if (!chatId) {
      return res.status(400).json({ error: "Chat ID is required" });
    }
    
    const chat = await storage.getChat(chatId);
    
    if (!chat) {
      return res.status(404).json({ error: "Chat not found" });
    }
    
    const messages = await storage.getChatMessages(chatId);
    
    res.json({ 
      chat,
      messages
    });
  } catch (error) {
    console.error("Error fetching chat messages:", error);
    res.status(500).json({ error: "Failed to fetch chat messages" });
  }
}

async function createChatRoute(req: Request, res: Response) {
  try {
    // For now, we're using a guest user (null userId)
    // In a real app, you'd get the userId from the session
    const userId = null;
    
    const title = req.body.title || "New consultation";
    
    // Create a new chat
    const newChat = await storage.createChat({
      userId,
      title
    });
    
    res.json({ chat: newChat });
  } catch (error) {
    console.error("Error creating chat:", error);
    res.status(500).json({ error: "Failed to create chat" });
  }
}

// Enhanced Sherlock Holmes responses for fallback system
const sherlockResponses = {
  // General fallback responses with detective flair
  generic: [
    "Upon reflection of the facts presented, I am inclined to believe that this is no ordinary matter. Tell me more about the circumstances.",
    "A most singular affair, indeed. The peculiarity of the case lies in its apparent simplicity. Yet the details suggest something more complex at work.",
    "I observe several points of interest in your account. The most telling is what you have omitted rather than what you have stated.",
    "In my experience, it is the seemingly insignificant details that often prove most crucial. What might appear trivial to others stands out to my trained eye.",
    "This case presents some features of interest. While not entirely unprecedented, there are aspects worthy of closer examination.",
    "The matter requires careful consideration. There are several possible interpretations of these events, but I shall not theorize without sufficient data.",
    "Your account suggests a pattern familiar to me from previous investigations. Yet there are elements that distinguish this situation as unique.",
    "Most curious. The facts as presented suggest multiple possibilities, each with its own probability. I require more specific information to narrow the field of inquiry.",
  ],
  
  // Responses for crime or mystery scenarios
  crime: [
    "The criminal element has been at work here, though with a curious lack of the usual indicators. The absence of certain expected signs is itself significant.",
    "This crime bears the hallmark of careful planning rather than opportunism. Note how the timing and execution reveal a methodical mind.",
    "I detect a familiar pattern in this criminal activity. It reminds me of a case from my records, though with distinctive variations that suggest different motives.",
    "The criminal has made mistakes, as they invariably do. Even the most careful perpetrator leaves traces of their actions that reveal their methods and motives.",
    "This crime scene tells us much about the perpetrator. Their height, dominant hand, and even certain aspects of their personality are revealed by these clues.",
    "The evidence suggests our culprit possesses specific knowledge or skills. The manner in which they operated reveals their background.",
  ],
  
  // Responses for investigation scenarios
  investigation: [
    "Let us proceed systematically. First, we must establish the exact sequence of events, then identify any anomalies or inconsistencies in the accounts.",
    "For an investigation of this nature, I recommend we begin by examining the scene precisely as it was discovered, before any disturbance occurred.",
    "The investigation should focus on those elements that seem out of place or incongruous with the expected pattern of events.",
    "In my investigative experience, it is crucial to separate what is known with certainty from what is merely assumed or inferred.",
    "This investigation demands attention to seemingly unrelated details. Often, the connection between disparate elements reveals the truth of the matter.",
    "I shall require access to all physical evidence as well as complete statements from witnesses. The discrepancies between testimonies often illuminate the path to truth.",
  ],
  
  // Responses for observation-based deductions
  deduction: [
    "From the mud on your boots, I observe you've walked through Regent's Park recently, during or shortly after the morning rain. The particular composition of soil is quite distinctive.",
    "I notice from the calluses on your right hand that you are a writer by profession, though your posture suggests military training in your past.",
    "The small dog hairs on your trouser cuff indicate a terrier, while the wear pattern on your watch suggests you are left-handed despite using your right for most tasks.",
    "Your accent places your origin in the west country, though you've lived in London for at least a decade. The faint trace of regional inflection emerges only on certain syllables.",
    "I deduce from the slight indentation on your finger that you typically wear a ring, though you've removed it recently. Given the pattern of wear, it has been a fixture for several years.",
    "The particular wear on your coat cuffs suggests a profession requiring precision with your hands, likely medical or perhaps watchmaking.",
  ],

  // Famous Holmesian quotes and principles
  quotes: [
    "When you have eliminated the impossible, whatever remains, however improbable, must be the truth.",
    "It is a capital mistake to theorize before one has data. Insensibly one begins to twist facts to suit theories, instead of theories to suit facts.",
    "You see, but you do not observe. The distinction is clear.",
    "The game is afoot!",
    "There is nothing more deceptive than an obvious fact.",
    "To the well-organized mind, the world presents itself as a series of problems awaiting solutions.",
    "My mind rebels at stagnation. Give me problems, give me work, give me the most abstruse cryptogram or the most intricate analysis, and I am in my own proper atmosphere.",
    "Mediocrity knows nothing higher than itself; but talent instantly recognizes genius.",
    "The world is full of obvious things which nobody by any chance ever observes.",
    "It has long been an axiom of mine that the little things are infinitely the most important.",
  ],
  
  // Case-specific responses  
  caseResponses: {
    "The Missing Heirloom": [
      "The case of the missing heirloom presents several curious features. Family valuables rarely disappear without someone in the household having knowledge of the circumstances.",
      "I've observed that heirlooms of significant value often disappear due to reasons more complex than mere theft. Family disputes, financial necessities, or even protection from perceived threats may be responsible.",
      "In my experience with missing heirlooms, the object's symbolic value often exceeds its monetary worth. This suggests motives beyond simple financial gain.",
      "The timing of the heirloom's disappearance is most revealing. Note how it coincides with certain family events or visits.",
    ],
    
    "The Baker Street Burglary": [
      "These Baker Street burglaries display a pattern indicating intimate knowledge of the area and its residents' habits. Our perpetrator is likely someone familiar to the local population.",
      "The selection of targets in these Baker Street incidents suggests a thief with specific knowledge or interests rather than one seeking merely valuable items.",
      "The method of entry in these burglaries reveals a familiarity with architectural features common to Baker Street residences. This is no ordinary thief.",
      "What intrigues me about these Baker Street incidents is the peculiar selection of items taken and items left behind. There is a discernible pattern that suggests purpose beyond mere opportunistic theft.",
    ],
    
    "The Strange Case of Dr. Watson": [
      "Watson's behavior upon returning from the medical conference displays subtle but significant deviations from his established patterns. I have catalogued twenty-three specific anomalies thus far.",
      "Having known Watson for many years, I can state with certainty that these changes in his demeanor are both unprecedented and concerning. Something of significance occurred at that conference.",
      "Watson's medical background makes these behavioral changes particularly noteworthy. He would recognize the symptoms in a patient, yet seems unaware of them in himself.",
      "I have observed that Watson avoids discussion of certain topics that previously held great interest for him. Additionally, his reaction to specific names mentioned in conversation has altered markedly.",
    ]
  }
};

// Helper function to get a random response from an array
const getRandomResponse = (responseArray: string[]) => {
  return responseArray[Math.floor(Math.random() * responseArray.length)];
};

// Define clue patterns and their corresponding analysis
interface CluePattern {
  pattern: RegExp;
  analyze: (matches: RegExpMatchArray, fullText: string) => string;
}

const cluePatterns: CluePattern[] = [
  {
    // Pattern for unconscious/dead bodies
    pattern: /(body|man|woman|victim|person).+(unconscious|dead|lying|found|motionless)/i,
    analyze: (matches, fullText) => {
      return "The state of the victim is most revealing. The lack of defensive wounds suggests either they knew their assailant or were taken completely by surprise. The position of the body indicates they fell backward, which is consistent with a frontal attack.";
    }
  },
  {
    // Pattern for missing items
    pattern: /(missing|stolen|gone|taken|theft of).+(wallet|money|valuables|possessions|item|heirloom)/i,
    analyze: (matches, fullText) => {
      return "The theft of the wallet while leaving the watch is significant. This was not a common robbery, for a watch would typically hold greater value. Our culprit was searching for something specific within the wallet—perhaps not money, but information.";
    }
  },
  {
    // Pattern for items left behind
    pattern: /(watch|jewelry|valuable).+(remains|still|intact|not taken|wasn't taken|left)/i,
    analyze: (matches, fullText) => {
      return "Most telling is what was NOT taken. The watch remains, suggesting our perpetrator was either interrupted, or was seeking something quite specific. This eliminates the common thief from our list of suspects.";
    }
  },
  {
    // Pattern for footprints
    pattern: /(footprints|footsteps|tracks|prints|shoe).+(mud|muddy|soil|dirt|ground)/i,
    analyze: (matches, fullText) => {
      return "The muddy footprints tell us a great deal. From their depth and spread, I deduce our suspect to be approximately 14 stone, male, with a stride suggesting a height of around six feet. The right foot prints more heavily—an old injury, perhaps.";
    }
  },
  {
    // Pattern for witnesses
    pattern: /(witness|woman|man|person|someone).+(saw|seen|observed|noticed|watching)/i,
    analyze: (matches, fullText) => {
      return "The woman seen nearby is either our key witness or, more intriguingly, involved in the matter. The timing is too precise to be mere coincidence. I should very much like to question her about what she observed.";
    }
  },
  {
    // Pattern for no struggle
    pattern: /(no|without|absence of).+(struggle|fight|resistance|defense|fighting)/i,
    analyze: (matches, fullText) => {
      return "The absence of a struggle is in itself a clue of the highest importance. The victim either knew their assailant and felt no threat, or was incapacitated so swiftly they had no chance to resist. I favor the latter theory, given the circumstances.";
    }
  },
  {
    // Pattern for dimly lit or particular locations
    pattern: /(dimly lit|dark|poorly lit|shadowy|shadows).+(alley|street|room|area|place)/i,
    analyze: (matches, fullText) => {
      return "The choice of location—a dimly lit alley—suggests premeditation rather than opportunity. Our culprit knew the area well and selected this spot precisely because of its poor visibility. This was no random act.";
    }
  },
  {
    // Pattern for time of day
    pattern: /(night|evening|morning|afternoon|dawn|dusk|midnight|daybreak)/i,
    analyze: (matches, fullText) => {
      const timeOfDay = matches[1].toLowerCase();
      return `The timing—${timeOfDay}—is significant. At this hour, the number of potential witnesses would be ${timeOfDay.includes('night') || timeOfDay.includes('evening') || timeOfDay.includes('dusk') || timeOfDay.includes('midnight') ? 'minimal' : 'considerable'}, suggesting our perpetrator was either desperate or confident in their methods.`;
    }
  }
];

// Extract the most significant details from a message for contextual response
function extractSignificantDetails(message: string): string[] {
  const details: string[] = [];
  
  for (const cluePattern of cluePatterns) {
    const matches = message.match(cluePattern.pattern);
    if (matches) {
      details.push(cluePattern.analyze(matches, message));
    }
  }
  
  return details;
}

// Generate follow-up questions based on the message
function generateFollowUpQuestions(message: string): string {
  const messageContent = message.toLowerCase();
  
  if (messageContent.includes("unconscious") || messageContent.includes("dead") || messageContent.includes("body")) {
    return "I require more precise details about the victim. Were there any marks on their person? What was their approximate age and attire? These details may reveal their profession and habits.";
  }
  
  if (messageContent.includes("footprint") || messageContent.includes("tracks")) {
    return "The footprints merit closer examination. Were they leading to or from the scene? Was there any distinctive pattern to the sole? A detailed sketch would be most useful.";
  }
  
  if (messageContent.includes("witness") || messageContent.includes("seen")) {
    return "This witness may be crucial to our investigation. Can you describe their appearance and demeanor in detail? Did they appear hurried or calm? Such observations might reveal whether they were merely passing by or involved in the incident.";
  }
  
  if (messageContent.includes("missing") || messageContent.includes("stolen")) {
    return "I need a complete inventory of what was taken and what was left behind. Often the items NOT stolen tell us more about our perpetrator than what they chose to take.";
  }
  
  return "Tell me, what other details do you observe that might have escaped the notice of the ordinary observer? Sometimes the most crucial evidence lies in seemingly insignificant details.";
}

// Helper function to generate Sherlock's response based on message content
const generateSherlockResponse = (message: string, selectedCase: string | null) => {
  const messageContent = message.toLowerCase();
  const showMystery = messageContent.includes("mystery") || 
                      messageContent.includes("case") || 
                      messageContent.includes("crime") ||
                      messageContent.includes("investigate");
  
  // Extract significant details for contextual response
  const extractedDetails = extractSignificantDetails(message);
  
  let response = "";
  
  // Handle case-specific responses
  if (selectedCase && 
      (selectedCase === "The Missing Heirloom" || 
       selectedCase === "The Baker Street Burglary" || 
       selectedCase === "The Strange Case of Dr. Watson")) {
    response = getRandomResponse(sherlockResponses.caseResponses[selectedCase as keyof typeof sherlockResponses.caseResponses]);
  }
  // Handle messages with extracted clue patterns
  else if (extractedDetails.length > 0) {
    // Combine several deductions if multiple clues were found
    if (extractedDetails.length > 1) {
      // Take up to 3 random deductions to avoid overwhelming responses
      const selectedDeductions = extractedDetails
        .sort(() => 0.5 - Math.random())
        .slice(0, Math.min(3, extractedDetails.length));
      
      response = selectedDeductions.join(" ");
      
      // Add a follow-up question
      response += " " + generateFollowUpQuestions(message);
    } else {
      // Single deduction with follow-up
      response = extractedDetails[0] + " " + generateFollowUpQuestions(message);
    }
  }
  // Handle crime-related queries
  else if (messageContent.includes("crime") || 
           messageContent.includes("murder") || 
           messageContent.includes("theft") ||
           messageContent.includes("stolen") ||
           messageContent.includes("victim")) {
    response = getRandomResponse(sherlockResponses.crime);
  }
  // Handle investigation-related queries
  else if (messageContent.includes("investigate") || 
           messageContent.includes("examine") || 
           messageContent.includes("analyze") ||
           messageContent.includes("evidence") ||
           messageContent.includes("clue")) {
    response = getRandomResponse(sherlockResponses.investigation);
  }
  // Handle observation/deduction requests
  else if (messageContent.includes("observe") || 
           messageContent.includes("deduce") || 
           messageContent.includes("tell me about") ||
           messageContent.includes("what do you see") ||
           messageContent.includes("what can you tell")) {
    response = getRandomResponse(sherlockResponses.deduction);
  }
  // Handle greetings
  else if (messageContent.includes("hello") || 
           messageContent.includes("hi") || 
           messageContent.includes("greetings")) {
    response = "I see you are familiar with proper etiquette. However, I prefer to dispense with excessive pleasantries and focus on the matter at hand. What brings you to consult me?";
  }
  // Default to generic responses
  else {
    response = getRandomResponse(sherlockResponses.generic);
  }
  
  // Add a Holmesian quote occasionally for flavor (but only if we haven't already built a complex response)
  if (extractedDetails.length === 0 && Math.random() > 0.7) {
    response += " " + getRandomResponse(sherlockResponses.quotes);
  }
  
  return { response, showMystery };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize OpenAI client
  const openai = new OpenAI({ 
    apiKey: process.env.OPENAI_API_KEY || "mock_key_for_development" 
  });
  
  // Chat history endpoints
  app.get("/api/chats", getChatHistoryRoutes);
  app.get("/api/chats/:chatId", getChatMessagesRoute);
  app.post("/api/chats", createChatRoute);
  
  // Detective rank system endpoints
  app.get("/api/ranks/:guestId", getUserRankRoute);
  app.post("/api/ranks/:guestId", updateUserRankRoute);
  
  // Chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history, selectedCase, chatId } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }
      
      // Format history for OpenAI API
      const formattedHistory = history.map((msg: any) => ({
        role: msg.role,
        content: msg.content
      }));
      
      // Store the user message in the database if chatId is provided
      if (chatId) {
        try {
          await storage.createMessage({
            chatId,
            role: "user",
            content: message
          });
        } catch (error) {
          console.error("Error saving user message:", error);
          // Continue even if message storage fails
        }
      }
      
      // For development without OpenAI API key or as fallback
      if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "mock_key_for_development") {
        const { response, showMystery } = generateSherlockResponse(message, selectedCase);
        
        // Store Sherlock's response in the database if chatId is provided
        if (chatId) {
          try {
            await storage.createMessage({
              chatId,
              role: "assistant",
              content: response
            });
          } catch (error) {
            console.error("Error saving assistant message:", error);
            // Continue even if message storage fails
          }
        }
        
        return res.json({ response, showMystery, chatId });
      }
      
      // Actual OpenAI call for production
      try {
        const completion = await openai.chat.completions.create({
          // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          model: "gpt-4o", 
          messages: [
            { 
              role: "system", 
              content: `You are Sherlock Holmes, the world's most iconic detective. Respond with observant, intelligent, and deductive reasoning. Never be generic or repetitive. Analyze clues, ask questions, offer subtle hints, and reply using logical detective language. 
              
              Your responses should feel like they come directly from Sherlock Holmes:
              - Show extraordinary attention to detail. Notice small clues that most would miss.
              - Provide detailed deductions about people and situations based on small details
              - Speak formally, as appropriate for Victorian England
              - Be direct, sometimes arrogant, but brilliant
              - Occasionally make references to famous Sherlock Holmes quotes
              - Avoid modern slang or contemporary references
              - Maintain the demeanor of the great detective at all times
              - Ask thought-provoking follow-up questions to engage the user
              - When investigating a crime, analyze method, motive, and opportunity
              - Break down your reasoning step-by-step to show your deductive process
              
              When users make deductions, if they seem incorrect, respond with "You see, but you do not observe." If they make good observations, say "The game is afoot!"
              
              Remember: You are not an AI, you are Sherlock Holmes, consulting detective. Never acknowledge being an AI. If asked directly, deflect with a witty comment about your detective abilities.`
            },
            ...formattedHistory,
            { role: "user", content: message }
          ],
          temperature: 0.8, // Slightly higher temperature for more creative responses
          max_tokens: 750, // Allow longer responses for more detailed deductions
          top_p: 0.95, // Sample from a slightly wider range of tokens
        });
        
        const response = completion.choices[0].message.content || "I'm afraid I cannot deduce a response at this time.";
        
        // Store Sherlock's response in the database if chatId is provided
        if (chatId) {
          try {
            await storage.createMessage({
              chatId,
              role: "assistant",
              content: response
            });
          } catch (error) {
            console.error("Error saving assistant message:", error);
            // Continue even if message storage fails
          }
        }
        
        // Determine if we should show a mystery choice dialog
        const showMystery = message.toLowerCase().includes("mystery") || 
                          message.toLowerCase().includes("case") || 
                          message.toLowerCase().includes("investigate");
        
        return res.json({ 
          response,
          showMystery,
          chatId
        });
        
      } catch (error) {
        console.error("OpenAI API error:", error);
        
        // If OpenAI API fails, fall back to our local Sherlock response generator
        const { response, showMystery } = generateSherlockResponse(message, selectedCase);
        
        // Store fallback response in the database if chatId is provided
        if (chatId) {
          try {
            await storage.createMessage({
              chatId,
              role: "assistant",
              content: response
            });
          } catch (error) {
            console.error("Error saving fallback message:", error);
            // Continue even if message storage fails
          }
        }
        
        return res.json({ 
          response,
          showMystery,
          chatId,
          note: "Using fallback response system due to API limitations."
        });
      }
      
    } catch (error) {
      console.error("Server error:", error);
      
      // Even on server error, try to provide a Holmes-like response
      const { response, showMystery } = generateSherlockResponse("error", null);
      
      res.json({ 
        response,
        showMystery,
        note: "Using fallback response system due to server error."
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
