import { useState, useEffect, useCallback } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ChatInterface from "@/components/ChatInterface";
import SidePanel from "@/components/SidePanel";
import MysteryChoices from "@/components/MysteryChoices";
import { Message, MysteryOption } from "@/lib/types";
import { initialMessage, getMysteryScenario } from "@/lib/sherlock-data";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";

// Custom hook for local storage
function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  // State to store our value
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === "undefined") {
      return initialValue;
    }
    try {
      // Get from local storage by key
      const item = window.localStorage.getItem(key);
      // Parse stored json or if none return initialValue
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      // If error also return initialValue
      console.log(error);
      return initialValue;
    }
  });

  // Return a wrapped version of useState's setter function that
  // persists the new value to localStorage.
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Allow value to be a function so we have same API as useState
      const valueToStore =
        value instanceof Function ? value(storedValue) : value;
      // Save state
      setStoredValue(valueToStore);
      // Save to local storage
      if (typeof window !== "undefined") {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      // A more advanced implementation would handle the error case
      console.log(error);
    }
  };

  return [storedValue, setValue];
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([initialMessage]);
  const [showMystery, setShowMystery] = useState(false);
  const [mysteryOptions, setMysteryOptions] = useState<MysteryOption[]>([]);
  const [mysteryPrompt, setMysteryPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedCase, setSelectedCase] = useState<string | null>(null);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [guestId, setGuestId] = useLocalStorage<string>("sherlock-guest-id", "");
  const { toast } = useToast();
  
  // Generate a guest ID if none exists
  useEffect(() => {
    if (!guestId) {
      const newGuestId = crypto.randomUUID();
      setGuestId(newGuestId);
    }
  }, [guestId, setGuestId]);

  // Fetch chat history
  const { 
    data: chatHistoryData,
    refetch: refetchChatHistory
  } = useQuery({
    queryKey: ['/api/chats'],
    queryFn: async () => {
      return await apiRequest('/api/chats');
    },
    refetchOnWindowFocus: false
  });

  // Create a new chat mutation
  const createChatMutation = useMutation({
    mutationFn: async (title: string) => {
      return await apiRequest('/api/chats', {
        method: 'POST',
        body: JSON.stringify({ title })
      });
    },
    onSuccess: (data) => {
      // Set the new chat as current
      if (data && data.chat) {
        setCurrentChatId(data.chat.id);
        setSelectedChatId(data.chat.id);
        // Refetch chat history
        refetchChatHistory();
        // Reset messages with initial message
        setMessages([initialMessage]);
      }
    },
    onError: (error) => {
      console.error('Error creating chat:', error);
      toast({
        title: "Error",
        description: "Failed to create a new consultation. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Load chat messages when selecting a chat from history
  const loadChatMessages = async (chatId: string) => {
    try {
      const response = await apiRequest(`/api/chats/${chatId}`);
      
      if (response && response.messages) {
        // Format messages for the UI
        const formattedMessages = response.messages.map((msg: any) => ({
          id: msg.id.toString(),
          role: msg.role,
          content: msg.content
        }));
        
        setMessages(formattedMessages.length > 0 ? formattedMessages : [initialMessage]);
        setCurrentChatId(chatId);
        setSelectedChatId(chatId);
      }
    } catch (error) {
      console.error('Error loading chat messages:', error);
      toast({
        title: "Error",
        description: "Failed to load the consultation history. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Function to add a new user message
  const addUserMessage = (content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content
    };
    setMessages(prev => [...prev, newMessage]);
    return newMessage;
  };

  // Function to add a new Sherlock message
  const addSherlockMessage = (content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      role: "assistant",
      content
    };
    setMessages(prev => [...prev, newMessage]);
    return newMessage;
  };

  // Start a new chat consultation
  const handleStartNewChat = useCallback(() => {
    const title = "New consultation - " + new Date().toLocaleString();
    createChatMutation.mutate(title);
  }, [createChatMutation]);

  // Function to handle rank progression
  const updateUserRank = async (action: string) => {
    if (!guestId) return;
    
    try {
      await apiRequest(`/api/ranks/${guestId}`, {
        method: 'POST',
        body: JSON.stringify({ action })
      });
    } catch (error) {
      console.error('Error updating rank:', error);
      // Silent failure - don't bother user with rank update errors
    }
  };

  // Check if the message contains analytical/logical reasoning
  const isLogicalQuestion = (message: string): boolean => {
    const logicalPatterns = [
      /why would|how could|what if|could it be|is it possible|deduction|analyze|analyse|logical|reasoning|deduce/i,
      /evidence suggests|pattern indicates|conclusion|therefore|hypothesis|theory|suspect/i,
      /connecting the dots|correlation|relationship between|cause and effect|motive/i
    ];
    
    return logicalPatterns.some(pattern => pattern.test(message));
  };
  
  // Check if the message contains clue analysis
  const containsClueAnalysis = (message: string): boolean => {
    const cluePatterns = [
      /footprint|fingerprint|blood|weapon|tool mark|hair|fiber|clue|evidence|trace/i,
      /broken|missing|displaced|unusual|odd|strange|peculiar|suspicious/i,
      /analyze this|what does this mean|significance of|importance of/i
    ];
    
    return cluePatterns.some(pattern => pattern.test(message));
  };
  
  // Function to handle sending a message
  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;
    
    // Create a new chat if none exists
    if (!currentChatId) {
      const title = "Consultation about " + content.substring(0, 20) + "...";
      await createChatMutation.mutateAsync(title);
      // The rest of the logic will continue after the chat is created
    }
    
    // Add user message
    addUserMessage(content);
    setLoading(true);
    
    // Update user's detective rank
    if (isLogicalQuestion(content)) {
      updateUserRank('askLogicalQuestion'); // Worth more points
    } else if (containsClueAnalysis(content)) {
      updateUserRank('analyzeClue');
    } else {
      updateUserRank('askQuestion'); // Basic question
    }
    
    try {
      // Make API call to get Sherlock's response
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: content, 
          history: messages,
          selectedCase,
          chatId: currentChatId
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to get response from Sherlock');
      }
      
      const data = await response.json();
      
      // Add Sherlock's response
      addSherlockMessage(data.response);
      
      // Update chat ID if returned
      if (data.chatId && !currentChatId) {
        setCurrentChatId(data.chatId);
        setSelectedChatId(data.chatId);
        // Refetch chat history to show the new chat
        refetchChatHistory();
      }
      
      // If there's a mystery scenario to display
      if (data.showMystery) {
        const scenario = getMysteryScenario();
        setMysteryPrompt(scenario.prompt);
        setMysteryOptions(scenario.options);
        setShowMystery(true);
      }
      
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Communication Error",
        description: "I seem to have lost connection to Baker Street. Please try again.",
        variant: "destructive"
      });
      
    } finally {
      setLoading(false);
    }
  };

  // Handle mystery choice selection
  const handleMysteryChoice = (option: MysteryOption) => {
    setShowMystery(false);
    
    // Add user choice as a message
    const userChoice = `I think we should ${option.title.toLowerCase()}.`;
    addUserMessage(userChoice);
    
    // This counts as solving a mystery - update the rank
    updateUserRank('solveMystery');
    
    // Save user choice to database
    if (currentChatId) {
      fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userChoice, 
          history: messages,
          selectedCase,
          chatId: currentChatId
        })
      }).catch(err => console.error('Error saving mystery choice:', err));
    }
    
    // Add Sherlock's response to the choice
    setTimeout(() => {
      addSherlockMessage(option.response);
      
      // Save Sherlock's response to database
      if (currentChatId) {
        fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            message: option.response, 
            history: [...messages, { id: Date.now().toString(), role: 'user', content: userChoice }],
            selectedCase,
            chatId: currentChatId,
            role: 'assistant'
          })
        }).catch(err => console.error('Error saving mystery response:', err));
      }
    }, 1000);
  };

  // Handle selecting a case file
  const handleSelectCase = (caseName: string) => {
    setSelectedCase(caseName);
    const caseIntroduction = `Ah, the case of "${caseName}". Let us examine the facts at our disposal. What details do you recall about this particular affair?`;
    addSherlockMessage(caseIntroduction);
    
    // If we have an active chat, save this message
    if (currentChatId) {
      fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: caseIntroduction,
          history: messages,
          selectedCase: caseName,
          chatId: currentChatId,
          role: 'assistant'
        })
      }).catch(err => console.error('Error saving case selection:', err));
    }
  };

  // Format chat history for SidePanel
  const formattedChatHistory = chatHistoryData?.chats ? chatHistoryData.chats : [];

  // Effect to create a new chat when the component mounts
  useEffect(() => {
    if (!currentChatId && !createChatMutation.isPending) {
      handleStartNewChat();
    }
  }, [currentChatId, createChatMutation.isPending, handleStartNewChat]);

  return (
    <div className="flex flex-col min-h-screen bg-sherlock-background">
      <Header />
      
      <main className="flex-grow container mx-auto p-4 flex flex-col md:flex-row gap-4">
        <ChatInterface 
          messages={messages} 
          onSendMessage={handleSendMessage}
          loading={loading}
        />
        
        <SidePanel 
          onSelectCase={handleSelectCase}
          selectedCase={selectedCase}
          chatHistory={formattedChatHistory}
          onStartNewChat={handleStartNewChat}
          onSelectChatHistory={loadChatMessages}
          selectedChatId={selectedChatId}
        />
      </main>
      
      <MysteryChoices 
        isOpen={showMystery}
        onClose={() => setShowMystery(false)}
        prompt={mysteryPrompt}
        options={mysteryOptions}
        onSelectOption={handleMysteryChoice}
      />
      
      <Footer />
    </div>
  );
}
