import { Settings, HelpCircle, LogOut } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-sherlock-primary text-white p-4 mt-4">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="mb-4 md:mb-0">
          <p className="font-playfair text-lg">221B Baker Street, London</p>
        </div>
        <div className="flex items-center space-x-4">
          <button className="text-white hover:text-sherlock-secondary transition-colors" aria-label="Settings">
            <Settings className="h-5 w-5" />
          </button>
          <button className="text-white hover:text-sherlock-secondary transition-colors" aria-label="Help">
            <HelpCircle className="h-5 w-5" />
          </button>
          <button className="text-white hover:text-sherlock-secondary transition-colors" aria-label="Exit">
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </div>
    </footer>
  );
}
