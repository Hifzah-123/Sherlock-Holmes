import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MysteryOption } from "@/lib/types";

interface MysteryChoicesProps {
  isOpen: boolean;
  onClose: () => void;
  prompt: string;
  options: MysteryOption[];
  onSelectOption: (option: MysteryOption) => void;
}

export default function MysteryChoices({
  isOpen,
  onClose,
  prompt,
  options,
  onSelectOption
}: MysteryChoicesProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-sherlock-lightBg w-full max-w-2xl mx-4 p-6 rounded-lg shadow-2xl paper-bg sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle className="font-playfair text-2xl font-bold mb-4 text-sherlock-primary border-b-2 border-sherlock-secondary pb-2">
            The Case Requires Your Decision
          </DialogTitle>
          <DialogDescription className="font-lora mb-6 text-lg text-sherlock-text">
            {prompt}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {options.map((option) => (
            <Card 
              key={option.id}
              className="bg-white/70 border-2 border-sherlock-secondary hover:border-sherlock-accent rounded-lg p-4 cursor-pointer transition-all hover:shadow-lg"
              onClick={() => onSelectOption(option)}
            >
              <div className="w-full h-32 flex items-center justify-center bg-gray-100 rounded mb-3">
                {option.icon}
              </div>
              <h3 className="font-special text-lg text-center text-sherlock-primary">
                {option.title}
              </h3>
            </Card>
          ))}
        </div>
        
        <div className="mt-6 text-right">
          <Button
            variant="link"
            className="text-sherlock-accent hover:text-sherlock-primary transition-colors"
            onClick={onClose}
          >
            Postpone decision
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
