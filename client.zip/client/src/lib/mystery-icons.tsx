import React from 'react';
import { Activity, User, FileText } from "lucide-react";

export const PulseIcon = () => <Activity className="w-12 h-12 text-sherlock-primary" />;
export const FootprintsIcon = () => <FileText className="w-12 h-12 text-sherlock-primary" />;
export const WitnessesIcon = () => <User className="w-12 h-12 text-sherlock-primary" />;