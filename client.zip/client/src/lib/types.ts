import { ReactNode } from "react";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export interface MysteryOption {
  id: string;
  title: string;
  description?: string;
  icon: ReactNode;
  response: string;
}

export interface MysteryScenario {
  prompt: string;
  options: MysteryOption[];
}

export interface Case {
  id: string;
  title: string;
  description: string;
  status: "open" | "closed" | "in-progress";
}

export interface Evidence {
  id: string;
  name: string;
  description: string;
  image: string;
  caseId?: string;
}
