import { useState } from "react";
import { Message } from "@/lib/types";
import { useSpeech } from "@/hooks/useSpeech";
import { MoveUp, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChatMessageProps {
  message: Message;
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const { speak, cancel } = useSpeech();
  
  const isSherlockMessage = message.role === "assistant";
  
  const handleListen = () => {
    if (isSpeaking) {
      cancel();
      setIsSpeaking(false);
    } else {
      speak(message.content, {
        onEnd: () => setIsSpeaking(false)
      });
      setIsSpeaking(true);
    }
  };
  
  return (
    <div 
      className={`mb-8 chat-bubble p-4 max-w-3xl ${
        isSherlockMessage ? "ml-4" : "mr-4 ml-auto user-bubble"
      }`}
    >
      <div className={`flex items-start ${isSherlockMessage ? "" : "justify-end"} mb-2`}>
        {isSherlockMessage ? (
          <>
            <div className="w-10 h-10 rounded-full mr-3 border-2 border-sherlock-secondary overflow-hidden">
              <svg viewBox="0 0 24 24" className="w-full h-full bg-white p-1" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" stroke="#3A3238" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M16 17l5-5-5-5" stroke="#3A3238" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M21 12H9" stroke="#3A3238" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <span className="font-bold text-sherlock-primary font-playfair">Sherlock Holmes</span>
          </>
        ) : (
          <>
            <span className="font-bold text-sherlock-primary font-playfair mr-3">You</span>
            <div className="w-10 h-10 rounded-full border-2 border-sherlock-secondary bg-white/80 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="#3A3238" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="7" r="4" stroke="#3A3238" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </>
        )}
      </div>
      
      <div className={isSherlockMessage ? "font-playfair italic text-lg mb-2" : "font-lora"}>
        {isSherlockMessage ? `"${message.content}"` : message.content}
      </div>
      
      {isSherlockMessage && (
        <div className="text-right">
          <Button
            onClick={handleListen}
            variant="ghost"
            size="sm"
            className="text-sherlock-accent hover:text-sherlock-primary transition-colors"
            aria-label={isSpeaking ? "Stop speaking" : "Listen to Sherlock's response"}
          >
            {isSpeaking ? <VolumeX className="h-4 w-4 mr-1" /> : <MoveUp className="h-4 w-4 mr-1" />} 
            {isSpeaking ? "Stop" : "Listen"}
          </Button>
        </div>
      )}
    </div>
  );
}
